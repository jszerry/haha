#!/bin/sh
uwsgi --reload uwsgi.pid
