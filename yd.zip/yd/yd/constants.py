# coding:utf-8
from threading import local, enumerate, Thread, currentThread
local_p = local()

COMMON_TYPE = (
             ('territory',u'行业领域'),
             ('category',u'项目类别'),
             ('nature',u'建设性质'),
             ('major_phase',u'重点项目建设阶段'),
             ('general_phase',u'一般项目建设阶段'),
             ('project_type',u'项目类型'),
             ('organization',u'机构'),
             ('scheme',u'方案情况'),
             )
STATE_TYPE=(
            ('1',u'启用'),
             ('0',u'停用'),
            )
IS_SUPERUSER=(
            ('1',u'是'),
             ('0',u'否'),
            )
