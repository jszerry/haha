# coding:utf-8
def menulist():
    menulist = [
                
#                 {"id":1,"code":"","name":u"系统概览","parent":None,"order":1},
                {"id":2,"code":"","name":u"客户信息管理","parent":None,"order":2},
                {"id":3,"code":"","name":u"标准地址信息管理","parent":None,"order":3},
              
                 {"id":4,"code":" back_stage_management","name":u"后台管理","parent":None,"order":4},
                
#                 {"id":11,'code':'SystemSurvey','name':u'系统扫描','url':'/SystemSurvey',"parent":1,"order":1},
                
                
               {"id":21,'code':'customerManage','name':u'用户信息管理','url':'/customerManage',"parent":2,"order":1},
               {"id":22,'code':'importExport','name':u'用户信息导入','url':'/importExport',"parent":2,"order":2},
               {"id":23,'code':'importRecordQuery','name':u'导入记录管理','url':'/importRecordQuery',"parent":2,"order":3},
               
               {"id":31,'code':'addressManage','name':u'标准地址信息管理','url':'/addressManage',"parent":3,"order":1},
               {"id":32,'code':'importStandard','name':u'标准地址导入','url':'/importStandard',"parent":3,"order":2},
               {"id":23,'code':'importStandardQuery','name':u'导入记录管理','url':'/importStandardQuery',"parent":3,"order":3},
                
                 {"id":41,'code':'roleManage','name':u'角色管理','url':'/roleManage',"parent":4,"order":1}, 
                 {"id":42,'code':'userManageQuery','name':u'账号管理','url':'/userManageQuery',"parent":4,"order":2},         
            ]
    return menulist