# coding:utf-8
from models import Role,Account
import menus

def createMenus(request):
    user1 = request.user
    user_id = user1.id
    acc=Account.objects.get(enabled=True,user_id=user_id)
    roleList = acc.roles.all()#得到用户所有的角色
    menus_list=[]
    for ur in roleList:
        menus_list = menus_list+map(int,(ur.menu).split(","))
    mlist = list(set(menus_list))
    menuslist=[]
    for m in menus.menulist():
        if m["id"] in mlist:
            menuslist.append(m)

    CMS_MENU = []
    for menu in menuslist:
        if not menu["parent"]:
            menu["submenus"]=[]
            for mm in menuslist:
                if mm["parent"] == menu["id"]:
                    menu["submenus"].append(mm) 
            CMS_MENU.append(menu)
    CMS_MENU.sort(lambda p1 , p2 : cmp(p1["order"] , p2["order"]))
    return CMS_MENU
    
        #user.
def initMenus(request):
    if request.user.is_authenticated() :
        menus = createMenus(request)
        return {
            'menus': menus,
        }
    return {}