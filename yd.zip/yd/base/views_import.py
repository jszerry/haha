# coding:utf-8

'''
    @author 陈峰
    @date 2015年11月10日 
    @description
           元数据的维护 增删改查方法
'''


from django.shortcuts import render, render_to_response
from django.http import HttpResponse
from django.template import RequestContext
from django.db.models import Q
import common,page_utils
import json, string
from django.http import HttpResponseRedirect
from models import *
import imp


'''
展示用户导入页面
'''
def importExport(request):
    context = RequestContext(request, {
            "result":None,
            "location":None,
        })
    return render_to_response("customer/importExport.html", context)

def IECongig(request):
    val = request.GET.get('val') 
    context = RequestContext(request, {
            "result":None,
            "location":None,
            "val":val,
        })
    return render_to_response("customer/importExport.html", context)

#导入用户信息
def importInfo(request):
    records = request.FILES.getlist('user_info')
    datajson = common.uploadExcel(records[0])
    infodata = common.excel_table_byindex(datajson['file_path'])
    area =u"区域"                            
    accNnmber =u"账号" 
    village_name =u"小区名称" 
    actual_address =u"安装实际地址" 
    SN =u"SN码" 
    accept_date =u"受理日期" 
    standard_address =u"资管6级标准地址" 
    OLT =u"OLT名称-槽位-端口" 
    cus_list=[]
    for info in infodata:
        try:
            _area=info.get(area,'')
            _village_name=info.get(village_name,'')
            _accNnmber=info.get(accNnmber,'')
            _actual_address=info.get(actual_address,'')
            _SN=str(int(info.get(SN,'')))
            _accept_date=info.get(accept_date,'')
            _standard_address=info.get(standard_address,'')
            _OLT=info.get(OLT,'')
        except:
            _area=None
            _accNnmber=None
            _village_name=None
            _actual_address=None
            _SN=None
            _accept_date=None
            _standard_address=None
            _OLT=None
        cus = Customer(
                       area=_area,
                       accNnmber=_accNnmber,
                       village_name=_village_name,
                       actual_address=_actual_address,
                       SN=_SN,
                       accept_date=_accept_date,
                       standard_address=_standard_address,
                       OLT=_OLT
                       )
        cus.save()
        cus_list.append(cus)
    #记录导入的记录数据
    acc = request.user
    a = Account.objects.filter(user=acc)
    importinfo = ImportInfo(account = a[0],excelName=datajson['excelName'])
    importinfo.save()
    importinfo.importCus=cus_list
    importinfo.save()
    ret = common.buildSuccess("导入excel成功")
    return HttpResponse(json.dumps(ret))

def importRecordQuery(request):
    acc = request.user
    a = Account.objects.filter(user=acc)
    importinfo = ImportInfo.objects.filter(account=a).order_by('-create_time')
    pageNum = request.GET.get('page', '1')
    context = RequestContext(request, {
        'result':page_utils.getPage(importinfo, pageNum),
        'page':pageNum
        })
    return render_to_response("customer/importRecordQuery.html", context)

customerlist=None
#查看导入的数据
def getRecordCustomer(request):
    global customerlist
    pageNum = request.GET.get('page', '1')
    id = request.GET.get("id")
    try:
        importinfo = ImportInfo.objects.get(id=id)
        customerlist = importinfo.importCus.all().order_by('create_time')
        result = page_utils.getPage(customerlist, pageNum)
    except:
        try:
            result = page_utils.getPage(customerlist, pageNum)
        except:
            result=None
    context = RequestContext(request, {
        'result':result,
        'page':pageNum
        })
    return render_to_response("customer/getRecordCustomer.html", context)


#导入用户查询
def customerManage(request):
    cond={}
    pageNum = request.POST.get('page', '1')
    village_name = request.POST.get('village_name','')
    accNnmber = request.POST.get('accNnmber','')
    actual_address = request.POST.get('actual_address','')
    SN = request.POST.get('SN','')
    if village_name:
        cond["village_name__contains"] = village_name
    if SN:
        cond["SN__contains"] = SN
    if accNnmber:
        cond["accNnmber__contains"] = accNnmber
    if actual_address:
        cond["actual_address__contains"] = actual_address
    customer = Customer.objects.filter(**cond).order_by('-create_time')
    context = RequestContext(request, {
        'result':page_utils.getPage(customer, pageNum),
        'village_name':village_name,
        'SN':SN,
        'accNnmber':accNnmber,
        'actual_address':actual_address,
        'page':pageNum,
        })
    return render_to_response("customer/customerManage.html", context)

#导出查询到的用户数据
def importCustomer(request):
    cond={}
    village_name = request.POST.get('village_name','')
    accNnmber = request.POST.get('accNnmber','')
    actual_address = request.POST.get('actual_address','')
    SN = request.POST.get('SN','')
    if village_name:
        cond["village_name__contains"] = village_name
    if SN:
        cond["SN__contains"] = SN
    if accNnmber:
        cond["accNnmber__contains"] = accNnmber
    if actual_address:
        cond["actual_address__contains"] = actual_address
    customer = Customer.objects.filter(**cond).order_by('-create_time')
    area =u"区域"                            
    accNnmber =u"账号" 
    village_name =u"小区名称" 
    actual_address =u"安装实际地址" 
    SN =u"SN码" 
    accept_date =u"受理日期" 
    standard_address =u"资管6级标准地址" 
    OLT =u"OLT名称-槽位-端口"
    excelName=u"用户数据"
    excelTop=[area,accNnmber,village_name,actual_address,SN,accept_date,standard_address,OLT]
    response = imp.excelPro(excelName,customer,excelTop)
    return response
    
    



def getCustomer(request):
    id = request.GET.get("id")
    page = request.GET.get("page")
    try:
        customer = Customer.objects.get(id=id)
    except:
        customer = None
    context = RequestContext(request, {
        're':customer,
        'page':page
        })
    return render_to_response("customer/customerEdit.html", context)

def customerDel(request):
    id = request.POST.get("id")
    m = Customer.objects.get(id=id)
    m.delete()
    ret = common.buildSuccess("删除成功")
    return HttpResponse(json.dumps(ret))

def delRecordCustomer(request):
    id = request.GET.get("id")
    page= request.GET.get("page",1)
    importinfo = ImportInfo.objects.get(id=id)
    cus_ist = importinfo.importCus.all()
    cus_ist.delete()
    importinfo.state=0
    importinfo.save()
    return HttpResponseRedirect('/importRecordQuery?page='+str(page))

def customerEdit(request):
    id= request.POST.get("id")
    page= request.POST.get("page",1)
    area= request.POST.get("area")
    accNnmber= request.POST.get("accNnmber")
    village_name= request.POST.get("village_name")
    actual_address= request.POST.get("actual_address")
    SN= request.POST.get("SN")
    accept_date= request.POST.get("accept_date")
    standard_address= request.POST.get("standard_address")
    OLT= request.POST.get("OLT")
    if not id:
        cus = Customer(     
                           area=area,
                           accNnmber=accNnmber,
                           village_name=village_name,
                           actual_address=actual_address,
                           SN=SN,
                           accept_date=accept_date,
                           standard_address=standard_address,
                           OLT=OLT
                           )
    else:
        cus = Customer.objects.get(id=id)
        cus.area=area
        cus.accNnmber=accNnmber
        cus.village_name=village_name
        cus.actual_address=actual_address
        cus.SN=SN
        cus.accept_date=accept_date
        cus.standard_address=standard_address
        cus.OLT=OLT
    cus.save()
    return HttpResponseRedirect('/customerManage?page='+str(page))










   
        
        
        
        
        
        
        
        
        
        
