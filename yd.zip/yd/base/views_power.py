# coding:utf-8

'''
    @author 陈峰
    @date 2015年11月10日 
    @description
           元数据的维护 增删改查方法
'''


from django.shortcuts import render
from django.shortcuts import render, render_to_response
from django.http import HttpResponse
from django.template import RequestContext
from django.db.models import Q
import common,page_utils,menus
import json, string
from django.http import HttpResponseRedirect
from models import *

'''
角色管理
'''
def roleManageQuery(request):
    result = Role.objects.filter(enabled=True).order_by('-create_time')
    context = RequestContext(request, {
            "result":result,
        })
    return render_to_response("userRole/role_manage_query.html", context)
def roleSelect(request):
    id = request.GET.get('id')
    result = Role.objects.filter(enabled=True).order_by('-create_time')
    context = RequestContext(request, {
            "result":result,
            "user_id":id,
            
        })
    return render_to_response("userRole/role_select.html", context)

def userRolesave(request):
    role_ids = request.POST.get("role_ids")
    user_id = request.POST.get("user_id")
    acc=Account.objects.get(id=user_id)
    if role_ids:
        ids = role_ids.split(',')
        rolelist = Role.objects.filter(id__in=ids)
    else:
        rolelist = []
    acc.roles = rolelist
    acc.save()
    ret = common.buildSuccess("授权成功")
    return HttpResponse(json.dumps(ret))


def userRoleQuery(request):
    user_id = request.POST.get("user_id")
    role_id_list=[]
    acc=Account.objects.get(id=user_id)
    role_ist = acc.roles.all()
    for m in role_ist:
        role_id_list.append(m.id)
    ret = common.buildSuccess(role_id_list)
    return HttpResponse(json.dumps(ret))



class Auth:
    number=''
    name=''
def roleAuthorize(request):
    menulist = menus.menulist
    id = request.GET.get("id")
    context = RequestContext(request, {
            "result":menulist,
            "role_id":id,
        })
    return render_to_response("userRole/role_authorize.html", context)
    
def roleMenuQuery(request):
    role_id = request.POST.get("role_id")
    r=Role.objects.get(id=role_id)
    ret = common.buildSuccess(r.menu)
    return HttpResponse(json.dumps(ret))

def roleMenuSave(request):
    role_id = request.POST.get("role_id")
    menu = request.POST.get("menus")
    r=Role.objects.get(id=role_id)
    r.menu = menu
    r.save()
    ret = common.buildSuccess("ok")
    return HttpResponse(json.dumps(ret))

def roleEdit(request):
    id = request.GET.get('id')
    re=None
    if id:
        re = Role.objects.get(pk=id)
    context = RequestContext(request, {
            "re":re,
    })
    return render_to_response("userRole/role_edit.html", context)

def roleSave(request):
    code = request.POST.get("code")
    name = request.POST.get("name")
    location = request.POST.get("location")
    description = request.POST.get("description")
    id = request.POST.get("id")
    if id:
        TF = Role.objects.filter(~Q(id=id),code=code,enabled=True)
    else:
        TF = Role.objects.filter(code=code,enabled=True)
    if TF:
        context = RequestContext(request, {
            "location":location,
            "errorMsg":u"编号已经存在，请重新填写编号",
            })
        return render_to_response("error.html", context)
    if not id:
        m = Role(name=name,code=code,description=description)
    else:
        m = Role.objects.get(id=id)
        m.code=code
        m.name=name
        m.description=description
    m.save()
    return HttpResponseRedirect('/roleManage')

def roleDel(request):
    id = request.POST.get("id")
    m = Role.objects.get(id=id)
    m.enabled = False
    m.save()
    ret = common.buildSuccess("删除成功")
    return HttpResponse(json.dumps(ret))



'''
用户管理
'''
def userManageQuery(request):
    accounts = Account.objects.all().order_by('-create_time')
    pageNum = request.GET.get('page', '1')
    context = RequestContext(request, {
        'result':page_utils.getPage(accounts, pageNum)
        })
    return render_to_response("userRole/user_manage_query.html", context)

def AddUser(request):
    id = request.GET.get('id')
    re=None
    if id:
        re = Account.objects.get(pk=id)
    context = RequestContext(request, {
            "re":re,
    })
    return render_to_response("userRole/userEdit.html", context)

# 用户新增、修改
def userEdit(request):
    id = request.POST.get('id')
    location = request.POST.get('location')
    is_superuser = request.POST.get('is_superuser')
    real_name = request.POST.get('real_name')
    username = request.POST.get('username')
    password = request.POST.get('password')
    confirm_password = request.POST.get('confirm_password')
    phone = request.POST.get('phone')
    email = request.POST.get('email')
    acc = None
    if id:
        try:
            acc = Account.objects.get(pk=id)
        except Account.DoesNotExist:
            pass
    user_id = acc.user.id if acc else None
    TF = User.objects.filter(~Q(id=user_id), username=username).exists()
    if TF:
        errorMsg=u"该账号存在，请重新填写账号"
        if confirm_password != password:
            errorMsg= errorMsg + u"两次密码不一致，请核对输入"
        context = RequestContext(request, {
            "location":location,
            "errorMsg":errorMsg,
            })
        return render_to_response("error.html", context)
    #如果是新增用户 则判断是否存在该账号
    if not id:
        u = User(username=username, email=email,is_superuser=is_superuser)
        u.set_password(password)
        u.save()
        acc = Account(real_name = real_name,phone = phone,user=u)
        acc.save()
    else:
        acc = Account.objects.get(id=id)
        user_id=acc.user_id
        acc.real_name = real_name
        acc.phone = phone
        u= acc.user
        u.username=username
        u.email=email
        u.is_superuser=is_superuser
        u.save()
        acc.save()
    return HttpResponseRedirect('/userManageQuery')

def userDel(request):
    id = request.POST.get("id")
    m = Account.objects.get(id=id)
    u = m.user
    u.delete()
    m.delete()
    ret = common.buildSuccess("删除成功")
    return HttpResponse(json.dumps(ret))
def passwordReset(request):
    id = request.POST.get("id")
    m = Account.objects.get(id=id)
    u = m.user
    u.set_password(123456)
    u.save()
    ret = common.buildSuccess("密码重置成功")
    return HttpResponse(json.dumps(ret))



def addOrganization(request):
    id = request.GET.get('id')
    re=None
    if id:
        re = Org.objects.get(pk=id)
    context = RequestContext(request, {
            "re":re,
    })
    return render_to_response("userRole/add_organization.html", context)

#计量单位类型保存修改
def organizationSave(request):
    code = request.POST.get("code")
    name = request.POST.get("name")
    location = request.POST.get("location")
    description = request.POST.get("description")
    type = request.POST.get("type")
    id = request.POST.get("id")
    if id:
        TF = Org.objects.filter(~Q(id=id),code=code,enabled=True)
    else:
        TF = Org.objects.filter(code=code,enabled=True)
    if TF:
        context = RequestContext(request, {
            "location":location,
            "errorMsg":u"编号已经存在，请重新填写编号",
            })
        return render_to_response("error.html", context)
    if not id:
        m = Org(name=name,code=code,description=description,type=type)
    else:
        m = Org.objects.get(id=id)
        m.code=code
        m.name=name
        m.description=description
        m.type=type
    m.save()
    return HttpResponseRedirect('/organizationManageQuery')

#报告期类型删除
def orgDel(request):
    id = request.POST.get("id")
    m = Org.objects.get(id=id)
    m.enabled = False
    m.save()
    ret = common.buildSuccess("删除成功")
    return HttpResponse(json.dumps(ret))



































