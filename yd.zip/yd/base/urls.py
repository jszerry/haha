# coding:utf-8
from django.conf.urls import patterns, include, url


from base import views,views_common,views_power,views_import,views_standard_addres

urlpatterns = patterns('',                       
                        url(r'^$',views.home),
                        url(r'^login$',views.login,name="base-login"),
                        url(r'^tool$',views.tool),
                        url(r'^logout$',views.logout),
                        url(r'^SystemSurvey$',views.SystemSurvey),

                    
                    #通用管理
                    
                    url(r'^commonCode$',views_common.commonCode),
                    url(r'^roleManage$',views_power.roleManageQuery),
                    url(r'^roleEdit$',views_power.roleEdit),
                    url(r'^roleSave$',views_power.roleSave),
                    url(r'^roleDel$',views_power.roleDel),
                    url(r'^roleAuthorize$',views_power.roleAuthorize),
                    url(r'^roleMenuQuery$',views_power.roleMenuQuery),
                    url(r'^roleMenuSave$',views_power.roleMenuSave),
                    url(r'^roleSelect$',views_power.roleSelect),
                       url(r'^userRolesave$',views_power.userRolesave),
                       url(r'^userRoleQuery$',views_power.userRoleQuery),
                    
                    url(r'^userManageQuery$',views_power.userManageQuery),
                       url(r'^userEdit$',views_power.userEdit),
                       url(r'^AddUser$',views_power.AddUser),
                       url(r'^userDel$',views_power.userDel),
                       url(r'^passwordReset$',views_power.passwordReset),
                       
                       
                       
                       url(r'^importExport$',views_import.importExport),
                       url(r'^IECongig$',views_import.IECongig),
                       url(r'^importInfo$',views_import.importInfo),
                       url(r'^importRecordQuery$',views_import.importRecordQuery),
                       url(r'^customerManage$',views_import.customerManage),
                       url(r'^customerDel$',views_import.customerDel),
                       url(r'^getCustomer$',views_import.getCustomer),
                       url(r'^customerEdit$',views_import.customerEdit),
                       url(r'^delRecordCustomer$',views_import.delRecordCustomer),
                       url(r'^getRecordCustomer$',views_import.getRecordCustomer),
                       url(r'^importCustomer$',views_import.importCustomer),
                       
                       
                       url(r'^importStandard$',views_standard_addres.importStandard),
                       url(r'^importStandardInfo$',views_standard_addres.importStandardInfo),
                       url(r'^addressManage$',views_standard_addres.addressManage),
                       url(r'^importStandardQuery$',views_standard_addres.importStandardQuery),
                       url(r'^delStandardQuery$',views_standard_addres.delStandardQuery),
                       url(r'^getStandardQuery$',views_standard_addres.getStandardQuery),
                       url(r'^standardDel$',views_standard_addres.standardDel),
                       url(r'^getAddress$',views_standard_addres.getAddress),
                       url(r'^standardEdit$',views_standard_addres.standardEdit),
                       url(r'^importAddress$',views_standard_addres.importAddress),
                    
)
