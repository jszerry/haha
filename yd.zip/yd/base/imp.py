# coding:utf-8
from django.http import HttpResponse
import xlwt

setStyle = xlwt.easyxf("align: wrap on ,horiz centre ,vert centre; border: left 1 ,right 1 , top 1 , bottom 1")




def excelPro(excelName,customer,excelTop):
    wb =xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet(excelName)
    ws.write(0, 0, '序号',setStyle)
    row = 0
    for exceltop in excelTop:
        row = row + 1
        ws.write(0, row, exceltop,setStyle)
    temp_count=0
    for da in customer:
        temp_count=temp_count+1
        ws.write(temp_count, 0, temp_count,setStyle)
        ws.write(temp_count, 1, da.area,setStyle)
        ws.write(temp_count, 2, da.accNnmber,setStyle)
        ws.write(temp_count, 3, da.village_name ,setStyle)
        ws.write(temp_count, 4, da.actual_address,setStyle)
        ws.write(temp_count, 5, da.SN ,setStyle)
        ws.write(temp_count, 6, da.accept_date,setStyle)
        ws.write(temp_count, 7, da.standard_address,setStyle)
        ws.write(temp_count, 8, da.OLT,setStyle)
    response = HttpResponse(content_type='application/vnd.ms-excel')
    response['Content-Disposition'] = 'attachment; filename=%s' %(excelName.encode('gbk')+'.xls')
    wb.save(response)
    return response

def excelAddress(excelName,standardaddress,excelTop):
    wb =xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet(excelName)
    ws.write(0, 0, '序号',setStyle)
    row = 0
    for exceltop in excelTop:
        row = row + 1
        ws.write(0, row, exceltop,setStyle)
    temp_count=0
    for da in standardaddress:
        temp_count=temp_count+1
        ws.write(temp_count, 0, temp_count,setStyle)
        ws.write(temp_count, 1, da.area,setStyle)
        ws.write(temp_count, 2, da.roomName,setStyle)
        ws.write(temp_count, 3, da.deviceName ,setStyle)
        ws.write(temp_count, 4, da.devicePort,setStyle)
        ws.write(temp_count, 5, da.Level_one_box ,setStyle)
        ws.write(temp_count, 6, da.Level_one_beam_splitter ,setStyle)
        ws.write(temp_count, 7, da.Level_two_box,setStyle)
        ws.write(temp_count, 8, da.Level_two_device_six_address,setStyle)
        ws.write(temp_count, 9, da.Level_one_address,setStyle)
        ws.write(temp_count, 10, da.Level_two_address,setStyle)
        ws.write(temp_count, 11, da.Level_tree_address,setStyle)
        ws.write(temp_count, 12, da.Level_four_address,setStyle)
        ws.write(temp_count, 13, da.Level_five_address,setStyle)
        ws.write(temp_count, 14, da.Level_six_address,setStyle)
        ws.write(temp_count, 15, da.Level_seven_address,setStyle)
    response = HttpResponse(content_type='application/vnd.ms-excel')
    response['Content-Disposition'] = 'attachment; filename=%s' %(excelName.encode('gbk')+'.xls')
    wb.save(response)
    return response

    