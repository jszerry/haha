# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('base', '0005_customer_accnnmber'),
    ]

    operations = [
        migrations.AlterField(
            model_name='customer',
            name='OLT',
            field=models.CharField(default=None, max_length=128, null=True, verbose_name='OLT\u540d\u79f0-\u69fd\u4f4d-\u7aef\u53e3'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='customer',
            name='SN',
            field=models.CharField(default=None, max_length=128, null=True, verbose_name='SN\u7801'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='customer',
            name='accNnmber',
            field=models.CharField(default=None, max_length=128, null=True, verbose_name='\u533a\u57df'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='customer',
            name='accept_date',
            field=models.CharField(default=None, max_length=128, null=True, verbose_name='\u53d7\u7406\u65e5\u671f'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='customer',
            name='area',
            field=models.CharField(default=None, max_length=128, null=True, verbose_name='\u533a\u57df'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='customer',
            name='standard_address',
            field=models.CharField(default=None, max_length=128, null=True, verbose_name='\u8d44\u7ba16\u7ea7\u6807\u51c6\u5730\u5740'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='customer',
            name='village_name',
            field=models.CharField(default=None, max_length=128, null=True, verbose_name='\u5c0f\u533a\u540d\u79f0'),
            preserve_default=True,
        ),
    ]
