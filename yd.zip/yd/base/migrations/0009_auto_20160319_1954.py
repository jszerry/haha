# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('base', '0008_auto_20160305_0012'),
    ]

    operations = [
        migrations.CreateModel(
            name='ImportStandardAddressInfo',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('create_time', models.DateTimeField(auto_now_add=True, verbose_name='\u521b\u5efa\u65f6\u95f4')),
                ('create_by', models.IntegerField(default=1, null=True, verbose_name='\u521b\u5efa\u4eba')),
                ('update_time', models.DateTimeField(auto_now=True, verbose_name='\u66f4\u65b0\u65f6\u95f4')),
                ('update_by', models.IntegerField(default=1, null=True, verbose_name='\u66f4\u65b0\u4eba')),
                ('enabled', models.BooleanField(default=True, verbose_name='\u72b6\u6001')),
                ('excelName', models.CharField(default=None, max_length=128, null=True, verbose_name='excel\u540d\u79f0')),
                ('state', models.IntegerField(default=1, null=True, verbose_name='\u5bfc\u5165\u72b6\u6001')),
            ],
            options={
                'abstract': False,
                'db_table': 'gds_import_standard_address_info',
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='StandardAddress',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('create_time', models.DateTimeField(auto_now_add=True, verbose_name='\u521b\u5efa\u65f6\u95f4')),
                ('create_by', models.IntegerField(default=1, null=True, verbose_name='\u521b\u5efa\u4eba')),
                ('update_time', models.DateTimeField(auto_now=True, verbose_name='\u66f4\u65b0\u65f6\u95f4')),
                ('update_by', models.IntegerField(default=1, null=True, verbose_name='\u66f4\u65b0\u4eba')),
                ('enabled', models.BooleanField(default=True, verbose_name='\u72b6\u6001')),
                ('area', models.CharField(default=None, max_length=128, null=True, verbose_name='\u533a\u57df')),
                ('roomName', models.CharField(default=None, max_length=128, null=True, verbose_name='\u4e0a\u8054\u673a\u623f\u540d\u79f0')),
                ('deviceName', models.CharField(default=None, max_length=128, null=True, verbose_name='\u8bbe\u5907\u540d\u79f0')),
                ('devicePort', models.CharField(default=None, max_length=128, null=True, verbose_name='\u8bbe\u5907\u7aef\u53e3')),
                ('Level_one_box', models.CharField(default=None, max_length=128, verbose_name='1\u53ca\u5206\u7ea4\u7bb1\u540d\u79f0\u53ca\u4e03\u7ea7\u5730\u5740')),
                ('Level_one_beam_splitter', models.CharField(default=None, max_length=128, null=True, verbose_name='1\u7ea7\u5206\u5149\u5668\u578b\u53f7')),
                ('Level_two_box', models.CharField(default=None, max_length=128, null=True, verbose_name='\u4e8c\u7ea7\u5206\u5149\u7bb1\u7f16\u53f7')),
                ('Level_two_beam_splitter', models.CharField(default=None, max_length=128, null=True, verbose_name='\u4e8c\u7ea7\u5206\u7ea4\u7bb16\u7ea7\u5730\u5740')),
                ('Level_two_device', models.CharField(default=None, max_length=128, null=True, verbose_name='\u4e8c\u7ea7\u5206\u5149\u5668\u578b\u53f7')),
                ('Level_two_device_six_address', models.CharField(default=None, max_length=128, null=True, verbose_name='\u4e8c\u7ea7\u5206\u5149\u56686\u7ea7\u5730\u5740')),
                ('Level_one_address', models.CharField(default=None, max_length=128, null=True, verbose_name='\u4e00\u7ea7\u5730\u5740')),
                ('Level_two_address', models.CharField(default=None, max_length=128, null=True, verbose_name='\u4e8c\u7ea7\u5730\u5740')),
                ('Level_tree_address', models.CharField(default=None, max_length=128, null=True, verbose_name='\u4e09\u7ea7\u5730\u5740')),
                ('Level_four_address', models.CharField(default=None, max_length=128, null=True, verbose_name='\u56db\u7ea7\u5730\u5740')),
                ('Level_five_address', models.CharField(default=None, max_length=128, null=True, verbose_name='\u4e94\u7ea7\u5730\u5740')),
                ('Level_six_address', models.CharField(default=None, max_length=128, null=True, verbose_name='\u516d\u7ea7\u5730\u5740')),
                ('Level_seven_address', models.CharField(default=None, max_length=128, null=True, verbose_name='\u4e03\u7ea7\u5730\u5740')),
            ],
            options={
                'abstract': False,
                'db_table': 'gds_standard_address',
            },
            bases=(models.Model,),
        ),
        migrations.AddField(
            model_name='importstandardaddressinfo',
            name='SD_ISDI',
            field=models.ManyToManyField(to='base.StandardAddress'),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='importstandardaddressinfo',
            name='account',
            field=models.ForeignKey(default=None, verbose_name='\u5bfc\u5165\u8005', to='base.Account', null=True),
            preserve_default=True,
        ),
    ]
