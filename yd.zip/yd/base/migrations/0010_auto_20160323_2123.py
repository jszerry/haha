# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('base', '0009_auto_20160319_1954'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='standardaddress',
            name='Level_two_beam_splitter',
        ),
        migrations.RemoveField(
            model_name='standardaddress',
            name='Level_two_device',
        ),
        migrations.AlterField(
            model_name='standardaddress',
            name='Level_two_box',
            field=models.CharField(default=None, max_length=128, null=True, verbose_name='\u4e8c\u7ea7\u5206\u5149\u7bb1\u7f16\u53f7\uff08\u4e8c\u7ea7\u5206\u7ea4\u7bb16\u7ea7\u5730\u5740\uff09'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='standardaddress',
            name='Level_two_device_six_address',
            field=models.CharField(default=None, max_length=128, null=True, verbose_name='\u4e8c\u7ea7\u5206\u5149\u5668\u578b\u53f7\uff08\u4e8c\u7ea7\u5206\u5149\u56686\u7ea7\u5730\u5740\uff09'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='standardaddress',
            name='area',
            field=models.CharField(default=None, max_length=128, null=True, verbose_name='\u5c0f\u533a\u540d\u79f0'),
            preserve_default=True,
        ),
    ]
