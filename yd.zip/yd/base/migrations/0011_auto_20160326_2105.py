# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('base', '0010_auto_20160323_2123'),
    ]

    operations = [
        migrations.AlterField(
            model_name='standardaddress',
            name='Level_one_box',
            field=models.CharField(default=None, max_length=128, null=True, verbose_name='1\u53ca\u5206\u7ea4\u7bb1\u540d\u79f0\u53ca\u4e03\u7ea7\u5730\u5740'),
            preserve_default=True,
        ),
    ]
