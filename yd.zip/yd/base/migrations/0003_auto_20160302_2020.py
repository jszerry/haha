# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('base', '0002_customer_importinfo'),
    ]

    operations = [
        migrations.RenameField(
            model_name='importinfo',
            old_name='acc',
            new_name='account',
        ),
    ]
