# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('base', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='Customer',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('create_time', models.DateTimeField(auto_now_add=True, verbose_name='\u521b\u5efa\u65f6\u95f4')),
                ('create_by', models.IntegerField(default=1, null=True, verbose_name='\u521b\u5efa\u4eba')),
                ('update_time', models.DateTimeField(auto_now=True, verbose_name='\u66f4\u65b0\u65f6\u95f4')),
                ('update_by', models.IntegerField(default=1, null=True, verbose_name='\u66f4\u65b0\u4eba')),
                ('enabled', models.BooleanField(default=True, verbose_name='\u72b6\u6001')),
                ('village_name', models.CharField(default=None, max_length=128, verbose_name='\u5c0f\u533a\u540d\u79f0')),
                ('actual_address', models.CharField(default=None, max_length=128, verbose_name='\u5b89\u88c5\u5b9e\u9645\u5730\u5740')),
                ('SN', models.CharField(default=None, max_length=128, verbose_name='SN\u7801')),
                ('accept_date', models.CharField(default=None, max_length=128, verbose_name='\u53d7\u7406\u65e5\u671f')),
                ('standard_address', models.CharField(default=None, max_length=128, verbose_name='\u8d44\u7ba16\u7ea7\u6807\u51c6\u5730\u5740')),
                ('OLT', models.CharField(default=None, max_length=128, verbose_name='OLT\u540d\u79f0-\u69fd\u4f4d-\u7aef\u53e3')),
            ],
            options={
                'abstract': False,
                'db_table': 'gds_customer',
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='ImportInfo',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('create_time', models.DateTimeField(auto_now_add=True, verbose_name='\u521b\u5efa\u65f6\u95f4')),
                ('create_by', models.IntegerField(default=1, null=True, verbose_name='\u521b\u5efa\u4eba')),
                ('update_time', models.DateTimeField(auto_now=True, verbose_name='\u66f4\u65b0\u65f6\u95f4')),
                ('update_by', models.IntegerField(default=1, null=True, verbose_name='\u66f4\u65b0\u4eba')),
                ('enabled', models.BooleanField(default=True, verbose_name='\u72b6\u6001')),
                ('state', models.IntegerField(default=1, null=True, verbose_name='\u5bfc\u5165\u72b6\u6001')),
                ('acc', models.ForeignKey(default=None, verbose_name='\u5bfc\u5165\u8005', to='base.Account', null=True)),
                ('importCus', models.ManyToManyField(to='base.Customer')),
            ],
            options={
                'abstract': False,
                'db_table': 'gds_importInfo',
            },
            bases=(models.Model,),
        ),
    ]
