# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Account',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('create_time', models.DateTimeField(auto_now_add=True, verbose_name='\u521b\u5efa\u65f6\u95f4')),
                ('create_by', models.IntegerField(default=1, null=True, verbose_name='\u521b\u5efa\u4eba')),
                ('update_time', models.DateTimeField(auto_now=True, verbose_name='\u66f4\u65b0\u65f6\u95f4')),
                ('update_by', models.IntegerField(default=1, null=True, verbose_name='\u66f4\u65b0\u4eba')),
                ('enabled', models.BooleanField(default=True, verbose_name='\u72b6\u6001')),
                ('real_name', models.CharField(default=None, max_length=128, verbose_name='\u59d3\u540d')),
                ('phone', models.CharField(default=None, max_length=32, null=True, verbose_name='\u624b\u673a\u53f7\u7801')),
            ],
            options={
                'abstract': False,
                'db_table': 'gds_account',
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='CommonCode',
            fields=[
                ('create_time', models.DateTimeField(auto_now_add=True, verbose_name='\u521b\u5efa\u65f6\u95f4')),
                ('create_by', models.IntegerField(default=1, null=True, verbose_name='\u521b\u5efa\u4eba')),
                ('update_time', models.DateTimeField(auto_now=True, verbose_name='\u66f4\u65b0\u65f6\u95f4')),
                ('update_by', models.IntegerField(default=1, null=True, verbose_name='\u66f4\u65b0\u4eba')),
                ('enabled', models.BooleanField(default=True, verbose_name='\u72b6\u6001')),
                ('code_id', models.AutoField(serialize=False, verbose_name='\u4e3b\u952e', primary_key=True)),
                ('code_type', models.CharField(max_length=32, verbose_name='\u4ee3\u7801\u7c7b\u578b')),
                ('code_number', models.CharField(max_length=32, verbose_name='\u4ee3\u7801\u7f16\u53f7')),
                ('code_name', models.CharField(max_length=32, verbose_name='\u7f16\u7801\u540d\u79f0')),
                ('code_order', models.IntegerField(max_length=4, null=True, verbose_name='\u6392\u5e8f')),
                ('link', models.CharField(max_length=32, null=True, verbose_name='\u5173\u8054')),
                ('code_state', models.IntegerField(default=1, max_length=1, verbose_name='\u662f\u5426\u542f\u7528')),
                ('description', models.TextField(default=None, verbose_name='\u63cf\u8ff0')),
                ('territory_number', models.CharField(max_length=32, null=True, verbose_name='\u9879\u76ee\u7c7b\u522b\u4ee3\u7801\u7f16\u53f7\u5173\u8054')),
                ('scheme_number', models.CharField(max_length=32, null=True, verbose_name='\u4e09\u4e2a\u65b9\u6848\u4ee3\u7801\u7f16\u53f7\u5173\u8054')),
            ],
            options={
                'ordering': ['code_type'],
                'abstract': False,
                'db_table': 'CommonCode',
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Role',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('create_time', models.DateTimeField(auto_now_add=True, verbose_name='\u521b\u5efa\u65f6\u95f4')),
                ('create_by', models.IntegerField(default=1, null=True, verbose_name='\u521b\u5efa\u4eba')),
                ('update_time', models.DateTimeField(auto_now=True, verbose_name='\u66f4\u65b0\u65f6\u95f4')),
                ('update_by', models.IntegerField(default=1, null=True, verbose_name='\u66f4\u65b0\u4eba')),
                ('enabled', models.BooleanField(default=True, verbose_name='\u72b6\u6001')),
                ('name', models.CharField(default=None, max_length=128, verbose_name='\u89d2\u8272\u540d')),
                ('code', models.CharField(default=None, max_length=128, verbose_name='\u89d2\u8272\u7f16\u53f7')),
                ('menu', models.CharField(default=None, max_length=512, null=True, verbose_name='\u83dc\u5355')),
                ('description', models.TextField(default=None, verbose_name='\u63cf\u8ff0')),
            ],
            options={
                'ordering': ['create_time'],
                'abstract': False,
                'db_table': 'gds_role',
            },
            bases=(models.Model,),
        ),
        migrations.AddField(
            model_name='account',
            name='roles',
            field=models.ManyToManyField(to='base.Role'),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='account',
            name='user',
            field=models.OneToOneField(to=settings.AUTH_USER_MODEL),
            preserve_default=True,
        ),
    ]
