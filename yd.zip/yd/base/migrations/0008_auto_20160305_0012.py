# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('base', '0007_importinfo_excelname'),
    ]

    operations = [
        migrations.AddField(
            model_name='account',
            name='state',
            field=models.IntegerField(default=0, null=True, verbose_name='\u5f53\u524d\u8f6c\u6001'),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='customer',
            name='accNnmber',
            field=models.CharField(default=None, max_length=128, null=True, verbose_name='\u8d26\u53f7'),
            preserve_default=True,
        ),
    ]
