# coding:utf-8
from django import template
from django.template import Context, Template, loader, resolve_variable
from yd import constants
register = template.Library()

def select(type, value=None, blank=False, blankLabel='', *args, **kwargs):
    try:
        choices = getattr(constants, type)
    except:
        raise template.TemplateSyntaxError(" tag[select] 常量类型错误!")
    return {'choices': choices,'value':value, 'blank':blank, 'blankLabel':blankLabel, 'attrs':kwargs}
 
register.inclusion_tag('component/select.html')(select)

