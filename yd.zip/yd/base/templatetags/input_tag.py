# coding:utf-8
'''
Created on 2015年8月20日

@author: Administrator
'''
from django import template
from base.models import *
from django.db.models import Q
import time
register = template.Library()

@register.filter(is_safe=True) 
def timeStar(start_date):
    if start_date:
        html = "<input id='start_date' type='text' name='start_date' style='width:100px' value='%s'>"%(start_date)
    return html
@register.filter(is_safe=True)
def timeEnd(end_date):
    if end_date:
        html = "<input id='end_date' type='text' name='end_date' style='width:100px' value='%s'>"%(end_date)
    return html
@register.filter(is_safe=True)
def dataTiming(data_timing):
    if data_timing:
        html = "<input id='data_timing' type='text' name='data_timing' style='width:100px' value='%s'>"%(data_timing)
    return html
