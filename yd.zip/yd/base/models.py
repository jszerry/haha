# coding:utf-8
from django.db import models
from yd import constants
from django.contrib.auth.models import User

class GdsBase(models.Model):
    create_time = models.DateTimeField(verbose_name=u'创建时间', auto_now_add=True)
    create_by = models.IntegerField(verbose_name=u'创建人', null=True, default=1)
    update_time = models.DateTimeField(verbose_name=u'更新时间', auto_now=True)
    update_by = models.IntegerField(verbose_name=u'更新人', null=True, default=1)
    enabled = models.BooleanField(verbose_name=u'状态', default=True)
# 创建人、更新人设置
    def save(self, *args, **kwargs):
        if hasattr(constants.local_p, 'user'):
            uid = constants.local_p.user.id
        else:
            uid = 1
        if not self.create_by:
            self.create_by = uid
        self.update_by = uid
        super(GdsBase, self).save(*args, **kwargs)
        
    class Meta:
        abstract = True
#通用编码表
class CommonCode(GdsBase):
    code_id = models.AutoField(verbose_name=u'主键', primary_key=True)
    code_type=models.CharField(verbose_name=u'代码类型', max_length=32)
    code_number=models.CharField(verbose_name=u'代码编号', max_length=32)
    code_name=models.CharField(verbose_name=u'编码名称', max_length=32)
    code_order=models.IntegerField(verbose_name=u'排序', max_length=4,null=True)
    link=models.CharField(verbose_name=u'关联', max_length=32,null=True)
    code_state=models.IntegerField(verbose_name=u'是否启用', max_length=1,default=1)
    description = models.TextField(verbose_name=u'描述',default=None)
    territory_number=models.CharField(verbose_name=u'项目类别代码编号关联', max_length=32,null=True)
    scheme_number=models.CharField(verbose_name=u'三个方案代码编号关联', max_length=32,null=True)
    class Meta(GdsBase.Meta):
        db_table = 'CommonCode'
        ordering = ['code_type']    
        
# 角色表
class Role(GdsBase):
    name = models.CharField(verbose_name=u'角色名', max_length=128,default=None)
    code = models.CharField(verbose_name=u'角色编号', max_length=128,default=None)
    menu = models.CharField(verbose_name=u'菜单', max_length=512,null=True,default=None)
    description = models.TextField(verbose_name=u'描述',default=None)
    class Meta(GdsBase.Meta):
        db_table = 'gds_role'
        ordering = ['create_time']
# 账号表
class Account(GdsBase):
    user = models.OneToOneField(User)
    state = models.IntegerField(verbose_name=u'当前转态', null=True, default=0)
    real_name = models.CharField(verbose_name=u'姓名', max_length=128,default=None)
    phone = models.CharField(verbose_name=u'手机号码', max_length=32, null=True,default=None)
    roles = models.ManyToManyField(Role)
    class Meta(GdsBase.Meta):
        db_table = 'gds_account' 


#客服信息表
class Customer(GdsBase):
    area = models.CharField(verbose_name=u'区域', max_length=128,default=None,null=True)
    accNnmber = models.CharField(verbose_name=u'账号', max_length=128,default=None,null=True)
    village_name = models.CharField(verbose_name=u'小区名称', max_length=128,default=None,null=True)
    actual_address = models.CharField(verbose_name=u'安装实际地址', max_length=128,default=None)
    SN = models.CharField(verbose_name=u'SN码', max_length=128,default=None,null=True)
    accept_date = models.CharField(verbose_name=u'受理日期', max_length=128,default=None,null=True)
    standard_address = models.CharField(verbose_name=u'资管6级标准地址', max_length=128,default=None,null=True)
    OLT = models.CharField(verbose_name=u'OLT名称-槽位-端口', max_length=128,default=None,null=True)
    class Meta(GdsBase.Meta):
        db_table = 'gds_customer'

        
#导入excel记录表
class ImportInfo(GdsBase):
    account = models.ForeignKey(Account, verbose_name=u'导入者', null=True,default=None)
    excelName = models.CharField(verbose_name=u'excel名称', max_length=128,default=None,null=True)
    state = models.IntegerField(verbose_name=u'导入状态', null=True, default=1)
    importCus = models.ManyToManyField(Customer)
    class Meta(GdsBase.Meta):
        db_table = 'gds_importInfo'     
#标准地址信息
class StandardAddress(GdsBase):
    area = models.CharField(verbose_name=u'小区名称', max_length=128,default=None,null=True)
    roomName = models.CharField(verbose_name=u'上联机房名称', max_length=128,default=None,null=True)
    deviceName = models.CharField(verbose_name=u'设备名称', max_length=128,default=None,null=True)
    devicePort = models.CharField(verbose_name=u'设备端口', max_length=128,default=None,null=True)
    Level_one_box = models.CharField(verbose_name=u'1及分纤箱名称及七级地址', max_length=128,default=None,null=True)
    Level_one_beam_splitter = models.CharField(verbose_name=u'1级分光器型号', max_length=128,default=None,null=True)
    Level_two_box = models.CharField(verbose_name=u'二级分光箱编号（二级分纤箱6级地址）', max_length=128,default=None,null=True)
    Level_two_device_six_address = models.CharField(verbose_name=u'二级分光器型号（二级分光器6级地址）', max_length=128,default=None,null=True)
    Level_one_address = models.CharField(verbose_name=u'一级地址', max_length=128,default=None,null=True)
    Level_two_address= models.CharField(verbose_name=u'二级地址', max_length=128,default=None,null=True)
    Level_tree_address = models.CharField(verbose_name=u'三级地址', max_length=128,default=None,null=True)
    Level_four_address = models.CharField(verbose_name=u'四级地址', max_length=128,default=None,null=True)
    Level_five_address = models.CharField(verbose_name=u'五级地址', max_length=128,default=None,null=True)
    Level_six_address = models.CharField(verbose_name=u'六级地址', max_length=128,default=None,null=True)
    Level_seven_address = models.CharField(verbose_name=u'七级地址', max_length=128,default=None,null=True)
    class Meta(GdsBase.Meta):
        db_table = 'gds_standard_address'
#导入excel记录表
class ImportStandardAddressInfo(GdsBase):
    account = models.ForeignKey(Account, verbose_name=u'导入者', null=True,default=None)
    excelName = models.CharField(verbose_name=u'excel名称', max_length=128,default=None,null=True)
    state = models.IntegerField(verbose_name=u'导入状态', null=True, default=1)
    SD_ISDI = models.ManyToManyField(StandardAddress)
    class Meta(GdsBase.Meta):
        db_table = 'gds_import_standard_address_info' 