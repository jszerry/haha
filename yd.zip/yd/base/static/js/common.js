//返回方法
function goBack(){
	location.href=document.referrer;
}



/*jQuery().ready(function() {
	alert("999");
	jQuery("#mytable").validate({
		debug : true,
		submitHandler : function(form) {
			form.submit();
		}
	});
});*/


//删除
function del(url,id,t){ 
	if(!confirm("确认要删除？")){
	return
	} 
	jQuery.ajax({
		type : "post",
		async : false,
		dataType : "json",
		url : url,
		data : {
			id : id,
		},
		success : function(ret) {
			layer.msg("删除成功");
			//location.reload();
			var i=t.parentNode.parentNode;
			i.remove();
		},
		error : function() {
			layer.msg("删除失败");
		},
		complete : function() {
		}
	});
} 


