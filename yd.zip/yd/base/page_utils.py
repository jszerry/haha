# coding:utf-8
from django.core.paginator import Paginator, InvalidPage, EmptyPage
import os
import json
import StringIO
from django.http import HttpResponse

'''
            分页工具
'''
def getPage(resultlist,page_num=1,page_size=10):
    #   分页处理
    paginator = Paginator(resultlist, page_size)
    try:
        result = paginator.page(page_num or 1)
    except (EmptyPage, InvalidPage):
        result = paginator.page(paginator.num_pages)
    return result