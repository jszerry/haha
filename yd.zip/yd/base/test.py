# coding:utf-8
def buffleSort2(numbers):
    for j in range(len(numbers),1):
        print 'j------------'+str(j)
         

def buffleSort(numbers):
    for j in xrange(len(numbers)):
        for i in xrange(j):
            if numbers[i] > numbers[i+1]:
                
                numbers[i], numbers[i+1] = numbers[i+1], numbers[i]
            print numbers

def main():
    numbers = [10, 9, 8, 7,6, 5]
    buffleSort(numbers)



if __name__ == '__main__':
    main()

