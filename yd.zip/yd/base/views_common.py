# coding:utf-8

'''
    @author 陈峰
    @date 2015年11月14日 
    @description
           系统管理
'''
from django.shortcuts import render
from django.shortcuts import render, render_to_response
from django.http import HttpResponse
from django.template import RequestContext
from django.db.models import Q
import common,page_utils
import json, string
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse
from models import *

def commonCode(request):
    code_type=''
    code_number=''
    code_name=''
    if request.method == "GET":
        codeList = CommonCode.objects.filter(enabled=True)
        pageNum = request.GET.get('page', '1')
    else:
        code_type = request.POST.get("code_type")
        code_number = request.POST.get("code_number")
        code_name = request.POST.get("code_name")
        pageNum = request.POST.get('page', '1')
        codeList = CommonCode.objects.filter(Q(code_number__contains=code_number)&Q(code_name__contains=code_name)&Q(code_type__contains=code_type),enabled=True)
    bList = page_utils.getPage(codeList, pageNum)
    context = RequestContext(request, {
        "businessDataList":bList,                               
        "code_type":code_type,                               
        "code_number":code_number,                               
        "code_name":code_name,                               
    })
    return render_to_response("ipms/commonCode.html", context)
    

