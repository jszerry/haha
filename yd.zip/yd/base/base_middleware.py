# coding: utf-8
from django.http import HttpResponseRedirect
from yd import constants
from django.core.urlresolvers import reverse
import traceback
from urls import urlpatterns

white_list = [
              '/login',
              '/captcha',
              '/captchaCheck',
              ]

def avoid_login(url):
    for urlpattern in urlpatterns:
        if urlpattern.name and reverse(urlpattern.name)==url:
            return True
    return False

class LoginMiddleware(object):
    def process_request(self, request):
        pass
        if not avoid_login(request.path):
            if request.user.is_authenticated():
                constants.local_p.user = request.user
                request.session.set_expiry(request.session.get_expiry_age())
            else:
                constants.local_p.user = request.user
                return HttpResponseRedirect('/login')

               
            
    def process_exception(self, request, exception):
        traceback.print_exc()
