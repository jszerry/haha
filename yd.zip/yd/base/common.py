# coding:utf-8

import xlrd
from yd.settings import MEDIA_ROOT
import os
import psutil

from django.db import models
def buildFail(msg, data=None):
    rtn = {}
    rtn["code"] = 0 #0表示失败
    rtn["msg"] = msg
    rtn["data"] = data
    return rtn
def buildSuccess(data,msg=None):
    rtn = {}
    rtn["code"] = 1 #1表示成功
    rtn["msg"] = msg
    rtn["data"] = data
    return rtn

#对象转字典的方法
def Obj2Dict(obj):
    __dict = {}
    for k, v in obj.__dict__.items():
        if isinstance(v, models.Model):
            __dict[k] = Obj2Dict(v)
        else:
            __dict[k] = str(v)
    return __dict  




#根据索引获取Excel表格中的数据   参数:file：Excel文件路径     colnameindex：表头列名所在行的所以  ，by_index：表的索引
def excel_table_byindex(files):
    colnameindex=0
    by_index=0
    data = open_excel(files)
    table = data.sheets()[by_index]
    nrows = table.nrows #行数
    ncols = table.ncols #列数
    colnames =  table.row_values(colnameindex) #某一行数据
    list =[]
    for rownum in range(1,nrows):
        row = table.row_values(rownum)
        if row:
            app = {}
            for i in range(len(colnames)):
                app[colnames[i]] = row[i]
            list.append(app)
    return list

def open_excel(file= 'file.xls'):
    try:
        data = xlrd.open_workbook(file)
        return data
    except Exception,e:
        print str(e)
def uploadExcel(f):
    datajson={}
    file_path = ""
    excelName = f.name
    try:
        path = os.path.join(MEDIA_ROOT, 'excel/').replace('\\', '/')
        if not os.path.exists(path):  # 判断文件夹是否存在
            os.makedirs(path)  # 创建一个path的文件夹
        file_path =path + f.name
        destination = open(file_path, 'wb+')#写操作方式已二进制的方式来写进
        for chunk in f.chunks():
            destination.write(chunk)
        destination.close()
        datajson['excelName']=excelName
        datajson['file_path']=file_path
    except Exception, e:
        print e
    return datajson     

 
# def getCPUstate():  
#     interval=1
#     return str(psutil.cpu_percent(interval))+"%"  
# def getMemorystate():   
#         phymem = psutil.virtual_memory()  
#         memoryInfo={}
#         memoryInfo['memoryState']=str(phymem.percent)+'%'
#         memoryInfo['memorySY']=str(int(phymem.used/1024/1024))+"M"
#         memoryInfo['memoryZL']=str(int(phymem.total/1024/1024))+"M" 
#         return memoryInfo 



if __name__ == '__main__':
    pass