# coding:utf-8

import os
import json



#解析json配置文件
def getProperties(config_file,name):
    BASE_DIR = os.path.dirname(os.path.dirname(__file__))
    path = os.path.join(BASE_DIR, config_file)
    f = file(path);
    s = json.load(f)
    f.close
    if not s :
        return None
    return s[name]


    