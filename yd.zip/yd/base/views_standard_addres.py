# coding:utf-8

'''
    @author 陈峰
    @date 2015年11月10日 
    @description
           元数据的维护 增删改查方法
'''


from django.shortcuts import render, render_to_response
from django.http import HttpResponse
from django.template import RequestContext
from django.db.models import Q
import common,page_utils
import json, string
from django.http import HttpResponseRedirect
from models import *
import imp


'''
展示用户导入页面
'''
def importStandard(request):
    context = RequestContext(request, {
            "result":None,
            "location":None,
        })
    return render_to_response("standardAddressInfo/importExport.html", context)

#导入用户信息
def importStandardInfo(request):
    records = request.FILES.getlist('StandardInfo')
    datajson = common.uploadExcel(records[0])
    infodata = common.excel_table_byindex(datajson['file_path'])
    area =u"小区名称"                            
    roomName =u"上联机房名称" 
    deviceName = u'设备名称'
    devicePort = u"设备端口"
    
    Level_one_box = u"1及分纤箱名称及七级地址"
    Level_one_beam_splitter = u"1级分光器型号"
    
    Level_two_box = u"二级分光箱编号（二级分纤箱6级地址）"
    Level_two_device_six_address = u"二级分光器型号（二级分光器6级地址）"
    
    Level_one_address = u"一级地址"
    Level_two_address = u"二级地址"
    Level_tree_address = u"三级地址"
    Level_four_address = u"四级地址"
    Level_five_address = u"五级地址"
    Level_six_address = u"六级地址"
    Level_seven_address = u"七级地址"
    cus_list=[]
    for info in infodata:
        try:
            _area=info.get(area,'')
            _roomName=info.get(roomName,'')
            _deviceName=info.get(deviceName,'')
            _devicePort = info.get(devicePort,'')
            _Level_one_beam_splitter = info.get(Level_one_beam_splitter,'')
            _Level_one_box = info.get(Level_one_box,'')
            _Level_two_box = info.get(Level_two_box,'')
            _Level_two_device_six_address = info.get(Level_two_device_six_address,'')
            _Level_one_address = info.get(Level_one_address,'')
            _Level_two_address = info.get(Level_two_address,'')
            _Level_tree_address = info.get(Level_tree_address,'')
            _Level_four_address = info.get(Level_four_address,'')
            _Level_five_address = info.get(Level_five_address,'')
            _Level_six_address = info.get(Level_six_address,'')
            _Level_seven_address = info.get(Level_seven_address,'')
        except:
            _area=None
            _roomName=None
            _deviceName=None
            _devicePort = None
            _Level_one_beam_splitter = None
            _Level_one_box = None
            _Level_two_box = None
            _Level_two_device_six_address = None
            _Level_one_address = None
            _Level_two_address = None
            _Level_tree_address = None
            _Level_four_address = None
            _Level_five_address = None
            _Level_six_address = None
            _Level_seven_address = None
        sa = StandardAddress(
                       area =_area,                         
                        roomName =_roomName,
                        deviceName = _deviceName,
                        devicePort = _devicePort,
                        Level_one_beam_splitter = _Level_one_beam_splitter,
                        Level_one_box = _Level_one_box,
                        Level_two_box = _Level_two_box,
                        Level_two_device_six_address = _Level_two_device_six_address,
                        Level_one_address = _Level_one_address,
                        Level_two_address = _Level_two_address,
                        Level_tree_address = _Level_tree_address,
                        Level_four_address = _Level_four_address,
                        Level_five_address = _Level_five_address,
                        Level_six_address = _Level_six_address,
                        Level_seven_address = _Level_seven_address,
                       )
        sa.save()
        cus_list.append(sa)
    #记录导入的记录数据
    acc = request.user
    a = Account.objects.filter(user=acc)
    importstandardaddressinfo = ImportStandardAddressInfo(account = a[0],excelName=datajson['excelName'])
    importstandardaddressinfo.save()
    importstandardaddressinfo.SD_ISDI=cus_list
    importstandardaddressinfo.save()
    ret = common.buildSuccess("导入excel成功")
    return HttpResponse(json.dumps(ret))

def importStandardQuery(request):
    acc = request.user
    a = Account.objects.filter(user=acc)
    importinfo = ImportStandardAddressInfo.objects.filter(account=a).order_by('-create_time')
    pageNum = request.GET.get('page', '1')
    context = RequestContext(request, {
        'result':page_utils.getPage(importinfo, pageNum),
        'page':pageNum
        })
    return render_to_response("standardAddressInfo/importRecordQuery.html", context)

customerlist=None
#查看导入的数据
def getStandardQuery(request):
    global customerlist
    pageNum = request.GET.get('page', '1')
    id = request.GET.get("id")  
    try:
        importinfo = ImportStandardAddressInfo.objects.get(id=id)
        customerlist = importinfo.SD_ISDI.all().order_by('create_time')
        result = page_utils.getPage(customerlist, pageNum)
    except:
        try:
            result = page_utils.getPage(customerlist, pageNum)
        except:
            result=None
    context = RequestContext(request, {
        'result':result,
        'page':pageNum
        })
    return render_to_response("standardAddressInfo/getRecordCustomer.html", context)


#导入用户查询
def addressManage(request):
    cond={}
    pageNum = request.POST.get('page', '1')
    area = request.POST.get('area','')
    roomName = request.POST.get('roomName','')
    if area:
        cond["area__contains"] = area
    if roomName:
        cond["roomName__contains"] = roomName
    standardaddress = StandardAddress.objects.filter(**cond).order_by('-create_time')
    context = RequestContext(request, {
        'result':page_utils.getPage(standardaddress, pageNum),
        'roomName':roomName,
        'area':area,
        'page':pageNum,
        })
    return render_to_response("standardAddressInfo/standardAddressInfoManage.html", context)

#导出查询到的用户数据
def importAddress(request):
    cond={}
    area = request.POST.get('area','')
    roomName = request.POST.get('roomName','')
    if area:
        cond["area__contains"] = area
    if roomName:
        cond["roomName__contains"] = roomName
    standardaddress = StandardAddress.objects.filter(**cond).order_by('-create_time')
    area =u"小区名称"                            
    roomName =u"上联机房名称" 
    deviceName = u'设备名称'
    devicePort = u"设备端口"
    
    Level_one_box = u"1及分纤箱名称及七级地址"
    Level_one_beam_splitter = u"1级分光器型号"
    
    Level_two_box = u"二级分光箱编号（二级分纤箱6级地址）"
    Level_two_device_six_address = u"二级分光器型号（二级分光器6级地址）"
    
    Level_one_address = u"一级地址"
    Level_two_address = u"二级地址"
    Level_tree_address = u"三级地址"
    Level_four_address = u"四级地址"
    Level_five_address = u"五级地址"
    Level_six_address = u"六级地址"
    Level_seven_address = u"七级地址"
    excelName = u"家客客户标准地址信息表"
    excelTop=[area,roomName,deviceName,devicePort, Level_one_box,Level_one_beam_splitter,Level_two_box,Level_two_device_six_address,Level_one_address,Level_two_address,Level_tree_address,Level_four_address,Level_five_address,Level_six_address,Level_seven_address
              ]
    response = imp.excelAddress(excelName,standardaddress,excelTop)
    return response
    
    



def getAddress(request):
    id = request.GET.get("id")
    page = request.GET.get("page")
    try:
        customer = StandardAddress.objects.get(id=id)
    except:
        customer = None
    context = RequestContext(request, {
        're':customer,
        'page':page
        })
    return render_to_response("standardAddressInfo/customerEdit.html", context)

def standardDel(request):
    id = request.POST.get("id")
    m = StandardAddress.objects.get(id=id)
    m.delete()
    ret = common.buildSuccess("删除成功")
    return HttpResponse(json.dumps(ret))

def delStandardQuery(request):
    id = request.GET.get("id")
    page= request.GET.get("page",1)
    importinfo = ImportStandardAddressInfo.objects.get(id=id)
    cus_ist = importinfo.SD_ISDI.all()
    cus_ist.delete()
    importinfo.state=0
    importinfo.save()
    return HttpResponseRedirect('/importStandardQuery?page='+str(page))

def standardEdit(request):
    id= request.POST.get("id")
    page= request.POST.get("page",1)
    area= request.POST.get("area")
    roomName= request.POST.get("roomName")
    deviceName= request.POST.get("deviceName")
    devicePort= request.POST.get("devicePort")
    Level_one_beam_splitter= request.POST.get("Level_one_beam_splitter")
    Level_one_box= request.POST.get("Level_one_box")
    Level_two_box= request.POST.get("Level_two_box")
    Level_tree_address= request.POST.get("Level_tree_address")
    Level_four_address= request.POST.get("Level_four_address")
    Level_five_address= request.POST.get("Level_five_address")
    Level_six_address= request.POST.get("Level_six_address")
    Level_seven_address= request.POST.get("Level_seven_address")
    Level_two_device_six_address= request.POST.get("Level_two_device_six_address")
    Level_one_address= request.POST.get("Level_one_address")
    Level_two_address= request.POST.get("Level_two_address")
    if not id:
        sa = StandardAddress(     
                        area =area,                         
                        roomName =roomName,
                        deviceName = deviceName,
                        devicePort = devicePort,
                        Level_one_beam_splitter = Level_one_beam_splitter,
                        Level_one_box = Level_one_box,
                        Level_two_box = Level_two_box,
                        Level_two_device_six_address = Level_two_device_six_address,
                        Level_one_address = Level_one_address,
                        Level_two_address = Level_two_address,
                        Level_tree_address = Level_tree_address,
                        Level_four_address = Level_four_address,
                        Level_five_address = Level_five_address,
                        Level_six_address = Level_six_address,
                        Level_seven_address = Level_seven_address,
                           )
    else:
        sa = StandardAddress.objects.get(id=id)
        area =sa.area                   
        roomName = sa.roomName
        deviceName = sa.deviceName
        devicePort = sa.devicePort
        Level_one_beam_splitter = sa.Level_one_beam_splitter
        Level_one_box = sa.Level_one_box
        Level_two_box = sa.Level_two_box
        Level_two_device_six_address = sa.Level_two_device_six_address
        Level_one_address = sa.Level_one_address
        Level_two_address = sa.Level_two_address
        Level_tree_address = sa.Level_tree_address
        Level_four_address = sa.Level_four_address
        Level_five_address = sa.Level_five_address
        Level_six_address = sa.Level_six_address
        Level_seven_address = sa.Level_seven_address
    sa.save()
    return HttpResponseRedirect('/addressManage?page='+str(page))










   
        
        
        
        
        
        
        
        
        
        
