# coding:utf-8
from django.shortcuts import render, render_to_response
from django.http import HttpResponse
from django.template import RequestContext
import json, string, math
from django import forms
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.http import HttpResponseRedirect
import socket
from django.contrib import auth
import json, string
import utils
import common
from django.db.models import Q
from django.contrib.auth.models import User
from models import *
def home(request):
    return render_to_response("login.html")
'''
用户登录
'''
# def login(request):
#     if request.method == "POST":
#         user_name = request.POST.get("user_name");
#         pwd = request.POST.get("password");
#         user = auth.authenticate(username=user_name)
#         print user
#         if user is not None:
#             auth.login(request, user)
#             if request.POST.get('next'):
#                 return HttpResponseRedirect(request.POST.get('next'))
#             else:
#                 return HttpResponseRedirect('/myworkbench')
#         else:
#             return render_to_response("login.html", {'error':u"用户名或密码错误"})
#     else:
#         return render_to_response("login.html", {'next': request.GET.get('next') if request.GET.get('next') else ''})

#修改后
def login(request):
    contxt={}
    if request.method == "POST":
        user_account = request.POST.get("user_account");
        password = request.POST.get("password");
        user = auth.authenticate(username=user_account, password=password)
        if user:
            auth.login(request, user)
            a = Account.objects.get(user=user)
            a.state=1
            a.save()
            return HttpResponseRedirect('/customerManage')
        else:
            contxt['error']=u"用户名或密码错误"
            return render_to_response("login.html", contxt)
    else:
        next_url = request.GET.get('next') if request.GET.get('next') else ''
        contxt['next']=next_url
        return render_to_response("login.html", {'next': request.GET.get('next') if request.GET.get('next') else ''})
def logout(request):
        acc = request.user
        a = Account.objects.get(user=acc)
        a.state=0
        a.save()
        auth.logout(request)
        return HttpResponseRedirect('/login')
def myworkbench(request):
    return render_to_response("systemManage/myworkbench.html",context_instance=RequestContext(request)) 
    
def tool(request):
    return render_to_response("systemManage/tool.html")

def SystemSurvey(request):
    #CPU = common.getCPUstate()
   # memoryInfo = common.getMemorystate()
    account_count = Account.objects.all().count()
    account_count_true = Account.objects.filter(state=1).count()
    account_state =  str(float(account_count_true)/account_count*100) +'%'
    context = RequestContext(request, {
            "account_count":account_count,
            "account_count_true":account_count_true,
            "account_state":account_state,
#             "CPU":CPU,
#             "memoryState":memoryInfo['memoryState'],
#             "memorySY":memoryInfo['memorySY'],
#             "memoryZL":memoryInfo['memoryZL'],
        })
    return render_to_response("customer/index.html", context)
