#!/bin/sh
uwsgi -i uwsgi.ini
