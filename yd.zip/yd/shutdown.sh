#!/bin/sh
uwsgi --stop uwsgi.pid
