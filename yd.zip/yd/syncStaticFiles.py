# coding:utf-8
#!/usr/bin/env python
import os
import sys
reload(sys)
sys.setdefaultencoding('utf-8')

#同步静态资源文件
if __name__ == "__main__":
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "yd.settings")
    from django.core.management import execute_from_command_line
    path = os.path.dirname(__file__)
    print "="*30, 'collectstatic start:', "="*30
    execute_from_command_line([path, "collectstatic"])
    print "="*30, 'collectstatic end:', "="*30
