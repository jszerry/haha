# coding:utf-8
#!/usr/bin/env python
import os
import sys
reload(sys)
sys.setdefaultencoding('utf-8')

#同步数据库
if __name__ == "__main__":
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "yd.settings")
    
    from django.core.management import execute_from_command_line
    path = os.path.join(os.path.dirname(__file__), 'syncDatabase.py')
    print "="*30, 'makemigrations start:', "="*30
    execute_from_command_line([path, "makemigrations"])
    print "="*30, 'makemigrations end:', "="*30
    print "="*30, 'migrate start:', "="*30
    execute_from_command_line([path, "migrate"])
    print "="*30, 'migrate end:', "="*30
    print "="*30, 'loaddata start:', "="*30
#     initDataDir = os.path.join(os.path.dirname(__file__), 'initData')
#     for parent,dirnames,filenames in os.walk(initDataDir):
#         for filename in filenames:
#             if len(filename)<5 or filename[-4:]!='json':
#                 continue
#             path = os.path.join(initDataDir, filename)
#             execute_from_command_line([path, "loaddata", path])
    print "="*30, 'loaddata end:', "="*30
    print "同步数据库成功"